/**
  *******************************************************************************
  * @file    cube_hal.h
  * @author  SRA
  * @version v1.4.0
  * @date    22-Oct-2021
  * @brief   Header for cube_hal_l4.c
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _CUBE_HAL_H_
#define _CUBE_HAL_H_

/* Includes ------------------------------------------------------------------*/

#include "stm32l4xx_hal.h"
#include "STWIN.h"
#include "stm32l4xx_hal_conf.h"
#include "stm32l4xx_hal_def.h"

void SystemClock_Config(void);

#endif //_CUBE_HAL_H_

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
