Middlewares/FreeRTOS/portable/heap_4.o: \
 C:/ST/stsw-stwinkt01/STSW-STWINKT01_V2.2.0/Middlewares/Third_Party/FreeRTOS/Source/portable/MemMang/heap_4.c \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../../../Inc/FreeRTOSConfig.h \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/list.h
../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../../../Inc/FreeRTOSConfig.h:
../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../../../../../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:
../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../../../../../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
